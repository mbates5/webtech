// GravityCube.cpp: A program using the TL-Engine

#include <TL-Engine.h>	// TL-Engine include file and namespace
using namespace tle;

//library for drawing text
#include <sstream>
using namespace std;

void main()
{
	// Create a 3D engine (using TLX engine here) and open a window for it
	I3DEngine* myEngine = New3DEngine(kTLX);
	myEngine->StartWindowed();

	// Add default folder for meshes and other media
	myEngine->AddMediaFolder("C:\\ProgramData\\TL-Engine\\Media");
	myEngine->AddMediaFolder(".\\media");

	/**** Set up your scene here ****/

	enum EPositionState { Bottom, Top, MovingUp, MovingDown };
	EPositionState playerPosition = Bottom;
	float kGravity = 0.5f;
	float kGameSpeed = -0.05f;
	float cameraPan = 0;
	float defaultPosition = 40;
	float rotation = 90 / (defaultPosition * 2 / kGravity);
	float rSpawn = 0;
	bool  playerAlive = true;

	string displayText = "Hello";
	IFont* myFont = myEngine->LoadFont("Arial", 48);

	ICamera* myCamera;
	myCamera = myEngine->CreateCamera(kManual);
	myCamera->SetPosition(0, 0, -130);

	IMesh* backMesh = myEngine->LoadMesh("background.x");
	IModel* background1 = backMesh->CreateModel(0, 0, 10);
	IModel* background2 = backMesh->CreateModel(260, 0, 10);

	IMesh* platMesh = myEngine->LoadMesh("platform.x");
	IModel* platform1 = platMesh->CreateModel(0, 60, 0);
	IModel* platform2 = platMesh->CreateModel(0, -60, 0);
	IModel* platform3 = platMesh->CreateModel(260, 60, 0);
	IModel* platform4 = platMesh->CreateModel(260, -60, 0);

	IMesh* plaMesh = myEngine->LoadMesh("playerCube.x");
	IModel* playerCube = plaMesh->CreateModel(0, -40, 0);


	//combine platforms and background into a single object
	platform1->AttachToParent(background1);
	platform2->AttachToParent(background1);
	platform3->AttachToParent(background2);
	platform4->AttachToParent(background2);

	platform1->SetLocalPosition(0, 60, -10);
	platform2->SetLocalPosition(0, -60, -10);

	platform3->SetLocalPosition(0, 60, -10);
	platform4->SetLocalPosition(0, -60, -10);


	// The main game loop, repeat until engine is stopped
	while (myEngine->IsRunning())
	{
		// Draw the scene
		myEngine->DrawScene();

		/**** Update your scene each frame here ****/

		//display dummy UI text
		stringstream outText;
		outText << displayText;
		myFont->Draw(outText.str(), 0, 0, kWhite);


		//player input
		if (myEngine->KeyHit(Key_Space) && (playerPosition == Bottom || playerPosition == Top) && playerAlive == true) {
			if (playerPosition == Bottom) {
				playerPosition = MovingUp;
			}
			else if (playerPosition == Top) {
				playerPosition = MovingDown;
			}
		}//end if


		//player movement
		if (playerPosition == MovingUp) {
			if (playerCube->GetY() < defaultPosition) {
				playerCube->MoveY(kGravity);
				
				playerCube->RotateLocalZ(rotation);
			}
			else {
				playerPosition = Top;
			}
		}
		else if (playerPosition == MovingDown) {
			if (playerCube->GetY() > -defaultPosition) {
				playerCube->MoveY(-kGravity);
				playerCube->RotateLocalZ(rotation);
			}
			else {
				playerPosition = Bottom;
			}
		}//end if


		//scrolling background and game difficulty
		background1->MoveX(kGameSpeed);
		background2->MoveX(kGameSpeed);

		if (background1->GetX() <= -260) {
			background1->SetPosition(260, 0, 10);
		}
		else if (background2->GetX() <= -260) {
			background2->SetPosition(260, 0, 10);
		}//end if


	}//end loop

	// Delete the 3D engine now we are finished with it
	myEngine->Delete();
}
